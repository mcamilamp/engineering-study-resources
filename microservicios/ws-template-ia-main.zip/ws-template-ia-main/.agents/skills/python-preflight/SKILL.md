---
name: python-preflight
description: 'Ejecuta verificaciones de calidad (ruff, mypy, pytest) antes de commit. Se activa cuando el usuario dice: preflight, quality checks, verificar calidad, /python-preflight, o antes de commit.'
license: MIT
allowed-tools: Bash
---

# Python Preflight Quality Checks

Ejecuta todas las verificaciones de calidad antes de un commit en proyectos Python.

## Activación

Se activa cuando el usuario dice:
- "preflight"
- "quality checks"
- "verificar calidad"
- "/python-preflight"
- "antes de commit"
- "verificar python"

## Verificaciones a Ejecutar

Ejecutar los 4 checks en secuencia:
1. `ruff check .` - Linting
2. `ruff format --check .` - Formato
3. `mypy app/` - Tipos (ajustar ruta si es necesario)
4. `pytest` - Tests

## Proceso

### 1. Ruff Lint
- Ejecutar `ruff check .`
- **Si pasa**: marcar PASS y continuar
- **Si falla**: mostrar errores y preguntar si corregir automáticamente
- **Auto-fix**: ejecutar `ruff check --fix .`

### 2. Ruff Format
- Ejecutar `ruff format --check .`
- **Si pasa**: marcar PASS y continuar
- **Si falla**: mostrar diferencias y preguntar si corregir automáticamente
- **Auto-fix**: ejecutar `ruff format .`

### 3. MyPy
- Ejecutar `mypy app/` (ajustar ruta según estructura del proyecto)
- **Si pasa**: marcar PASS y continuar
- **Si falla**: mostrar errores de tipo y ofrecer corregirlos si son simples

### 4. Pytest
- Ejecutar `pytest`
- **Si pasa**: marcar PASS con count de tests
- **Si falla**: mostrar tests que fallan y ofrecer investigar

## Manejo de Errores

| Check | Si falla | Acción |
|-------|----------|--------|
| ruff lint | Mostrar errores | Ofrecer `ruff check --fix .` |
| ruff format | Mostrar diff | Ofrecer `ruff format .` |
| mypy | Mostrar errores de tipo | Ofrecer investigar |
| pytest | Mostrar tests fallidos | Ofrecer investigar |

## Output

Generar un reporte final:

```
## Preflight Results
- Ruff lint:   PASS/FAIL
- Ruff format: PASS/FAIL
- mypy:        PASS/FAIL
- pytest:      PASS/FAIL (N passed, M failed)
```

## Finalización

**Si todos los checks pasan**: preguntar al usuario:
- Pregunta: "Todos los checks pasaron. Listo para commit?"
- Opciones:
  - "Hacer commit" — pedir mensaje y ejecutar git commit
  - "Solo verificar" — termina aquí

**Si algún check falla**: terminar con mensaje indicando qué falló.

## Reglas

1. **No modificar archivos automáticamente**: siempre preguntar al usuario antes de auto-corregir
2. **Ejecutar en orden**: no saltar verificaciones
3. **Mostrar output relevante**: solo lo necesario para entender el problema
4. **Permitir interrumpir**: si el usuario decide no continuar, terminar gracefully
