# Security Next Score Skill

Evalúa la seguridad de un proyecto Next.js y genera un score de 0-100.

## Activación

Se activa cuando el usuario dice:
- "análisis de seguridad"
- "security score"
- "evaluar seguridad"
- "/security-next-score"
- "score security"

## Categorías de Evaluación

| # | Categoría | Aplica | Peso | Justificación |
|---|-----------|--------|------|---------------|
| 1 | Autenticación | ✅ | 15 | Uso de Auth0 |
| 2 | Autorización | ✅ | 15 | Control de acceso en rutas |
| 3 | Validación de Entrada | ✅ | 10 | Formularios y API |
| 4 | Inyección SQL | ❌ | 0 | No hay base de datos SQL en frontend |
| 5 | Secretos | ✅ | 15 | Variables de entorno + gitignore + scanning |
| 6 | Excepciones | ✅ | 10 | Manejo de errores |
| 7 | Ci/CD | ✅ | 5 | Configuración de pipeline |
| 8 | Headers & CORS | ✅ | 10 | next.config.js |
| 9 | Protección & HTTP | ✅ | 20 | Rutas + XSS + HTTP client + Estado |

**Total pesos aplicables**: 100

## Proceso de Evaluación

### 1. Autenticación (15 pts)
- Buscar uso de Auth0, NextAuth, JWT
- Verificar configuración en `src/auth/`, `src/lib/auth*.ts`
- **Archivos clave**: `src/lib/auth0.ts`, `src/auth/`

### 2. Autorización (15 pts)
- Verificar middleware de protección
- Buscar verificación de roles/permisos
- **Archivos clave**: `src/middleware.ts`, `src/auth/`

### 3. Validación de Entrada (10 pts)
- Buscar Zod, Yup, Joi
- Verificar sanitización de inputs
- **Archivos**: `src/lib/validation*.ts`, formularios en `src/components/`

### 4. Secretos (15 pts)
- Verificar `.env` en `.gitignore` (primera verificación)
- Si está en gitignore: ✅ - No hay riesgo de exposure
- Si NO está en gitignore: verificar contenido
  - Buscar `NEXT_PUBLIC_` para vars expuestas inadvertidamente
  - Verificar que no haya valores reales/hardcodeados
- Verificar `.git/hooks/` y config de gitleaks/trufflehog
- **Archivos**: `.env*`, `.gitignore`, `.gitleaks.*`, `trufflehog.yml`

### 5. Excepciones (10 pts)
- Buscar try/catch
- Verificar logging de errores
- **Archivos**: `src/app/api/**/route.ts`

### 6. Ci/CD (5 pts)
- Verificar pipeline de CI/CD
- Buscar análisis de seguridad en CI
- **Archivos**: `.github/workflows/*.yml`, `azure-pipelines.yml`

### 7. Headers & CORS (10 pts)
- Buscar configuración de headers en next.config.js
- Verificar CSP, HSTS, X-Frame-Options, X-Content-Type-Options
- Verificar configuración CORS
- **Archivos**: `next.config.js`, `next.config.mjs`, `src/app/api/**/route.ts`

### 8. Protección & HTTP (20 pts)
- Verificar rutas privadas con redirección a login
- Verificar protección XSS (no usar `dangerouslySetInnerHTML`)
- Verificar cliente HTTP seguro con timeout y manejo de errores
- Verificar que tokens NO se almacenen en localStorage (usar cookies HttpOnly)
- **Archivos**: `src/middleware.ts`, `src/app/(app)/layout.tsx`, `src/lib/api.ts`, `src/lib/fetcher.ts`, `src/auth/`

### 9. Dependencias Vulnerables (5 pts)
- Ejecutar `npm audit` o `npm audit --audit-level=high`
- Verificar `package-lock.json` actualizado

## Scoring

Para cada categoría aplicable (no marcada como 0):
- **Verde (1.0)**: Implementación completa y correcta
- **Amarillo (0.5)**: Implementación parcial o con mejoras necesarias
- **Rojo (0.0)**: No implementado o con problemas críticos

**Fórmula**:
```
Score = (Σ(categoría_puntos × calificación)) / (Σpesos_aplicables) × 100
```

## Output

Generar un reporte en formato:

```
## Security Score: XX/100

### Detalle por Categoría

| Categoría | Peso | Score | Estado |
|-----------|------|-------|--------|
| Autenticación | 15 | 15/15 | ✅ |
| Autorización | 15 | 7.5/15 | ⚠️ |
| ... | ... | ... | ... |

### Hallazgos

#### 🔴 Críticos
- [ ] ...

#### 🟡 Recomendaciones
- [ ] ...

#### 🟢 Implementado
- [ ] ...
```

## Reglas

1. **No modificar archivos**: Solo analizar y reportar
2. **Ser objetivo**: Calificar basado en evidencia encontrada
3. **Proponer soluciones**: En hallazgos, sugerir cómo mejorar
4. **Ejecutar comandos útiles**: `npm audit`, buscar patrones en código
