# FastAPI Clean Architecture Skill

## Proposito
Este skill guia el desarrollo de endpoints REST en newo-api usando FastAPI con arquitectura por capas (Layered Architecture) + Use Cases pattern. Optimizado para escalabilidad, mantenibilidad y codigo limpio.

## Stack Tecnologico

### Core
- **Python**: 3.12+
- **Framework**: FastAPI 0.115+
- **Database**: PostgreSQL 17.6 (Azure Database for PostgreSQL Flexible Server)
- **ORM**: SQLAlchemy 2.0 (async mode)
- **Migrations**: Alembic
- **Auth**: Auth0 via `auth0-fastapi-api` SDK

### Development & Quality
- **Linting & Formatting**: Ruff
- **Type Checking**: mypy (strict mode)
- **Testing**: pytest + pytest-asyncio + pytest-cov (80%+ coverage)
- **Pre-commit**: ruff + mypy + conventional-commits
- **Monitoring**: Sentry

## Flujo de Request (obligatorio)

```
HTTP Request
    ↓
[RequestLoggingMiddleware] — persiste request/response en tabla logs
    ↓
[Endpoint] — HTTP handling + Pydantic validation
    ↓
[Use Case] — orquestacion (una intencion = un use case)
    ↓
[Service] — logica de negocio pura, stateless
    ↓
[Repository] — queries + CRUD (filtra deleted == False)
    ↓
[Model] — SQLAlchemy + TimestampMixin + SoftDeleteMixin
    ↓
[Schema] — ApiResponse[T] envelope
    ↓
HTTP Response
```

## Patrones por Capa

### 1. Endpoints (`app/api/v1/endpoints/`)

```python
# ✅ CORRECTO
from fastapi import APIRouter, Depends
from app.api.v1.dependencies import get_current_user
from app.schemas.base import ApiResponse
from app.schemas.member import MemberResponse, MemberCreate

router = APIRouter(prefix="/members", tags=["members"])

@router.post("", response_model=ApiResponse[MemberResponse], status_code=201)
async def create_member(
    data: MemberCreate,
    use_case: CreateMemberUseCase = Depends(get_create_member_use_case),
    _: dict = Depends(get_current_user),
) -> ApiResponse[MemberResponse]:
    member = await use_case.execute(data)
    return ApiResponse(data=MemberResponse.model_validate(member))


@router.get("/{member_id}", response_model=ApiResponse[MemberResponse])
async def get_member(
    member_id: UUID,
    use_case: GetMemberUseCase = Depends(get_get_member_use_case),
    _: dict = Depends(get_current_user),
) -> ApiResponse[MemberResponse]:
    member = await use_case.execute(member_id)
    return ApiResponse(data=MemberResponse.model_validate(member))


# ❌ INCORRECTO — logica de negocio en endpoint
@router.post("/members")
async def create_member(data: MemberCreate, db: AsyncSession = Depends(get_db)):
    if await db.execute(select(Member).where(Member.login == data.login)).scalar():
        raise HTTPException(400, "Login exists")
    member = Member(**data.model_dump())
    db.add(member)
    await db.commit()
    return member
```

### 2. Use Cases (`app/use_cases/`)

```python
# ✅ CORRECTO
from app.repositories.member_repository import MemberRepository
from app.services.member_service import MemberService
from app.schemas.member import MemberCreate
from app.models.member import Member


class CreateMemberUseCase:
    def __init__(self, member_repository: MemberRepository, member_service: MemberService) -> None:
        self.member_repository = member_repository
        self.member_service = member_service

    async def execute(self, data: MemberCreate) -> Member:
        # 1. Validar reglas de negocio
        await self.member_service.validate_unique_login(data.login)
        # 2. Persistir
        return await self.member_repository.create(data)
```

### 3. Services (`app/services/`)

```python
# ✅ CORRECTO — stateless, sin HTTP
from app.repositories.member_repository import MemberRepository
from app.core.exceptions import ConflictException


class MemberService:
    def __init__(self, member_repository: MemberRepository) -> None:
        self.member_repository = member_repository

    async def validate_unique_login(self, login: str) -> None:
        existing = await self.member_repository.find_by_login(login)
        if existing:
            raise ConflictException(f"Login '{login}' already registered")
```

### 4. Repositories (`app/repositories/`)

```python
# ✅ CORRECTO — extiende BaseRepository
from app.repositories.base import BaseRepository
from app.models.member import Member
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession


class MemberRepository(BaseRepository[Member]):
    def __init__(self, session: AsyncSession):
        super().__init__(session, Member)

    async def find_by_login(self, login: str) -> Member | None:
        result = await self.session.execute(
            select(Member).where(
                Member.login == login,
                Member.deleted == False,  # noqa: E712
            )
        )
        return result.scalar_one_or_none()
```

**BaseRepository ya provee** (no re-implementar):
- `get_by_id(id: UUID) -> ModelT | None` — filtra `deleted == False`
- `find_all(page, per_page) -> tuple[list[ModelT], int]` — filtra `deleted == False`
- `soft_delete(id: UUID) -> None`

### 5. Models (`app/models/`)

```python
# ✅ CORRECTO — UUID PK + ambos mixins + indices
import uuid
from sqlalchemy import String, Boolean, Index
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column
from app.models.base import Base, TimestampMixin, SoftDeleteMixin


class SomeEntity(Base, TimestampMixin, SoftDeleteMixin):
    __tablename__ = "some_entities"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)

    __table_args__ = (
        Index("ix_some_entities_name", "name"),
    )


# ❌ INCORRECTO — int PK, sin mixins
class SomeEntity(Base):
    __tablename__ = "some_entities"
    id: Mapped[int] = mapped_column(primary_key=True)
```

**Mixins disponibles** (`app/models/base.py`):
- `TimestampMixin` — `created_at`, `updated_at` (auto)
- `SoftDeleteMixin` — `deleted: bool = False`, `deleted_at: datetime | None`

### 6. Schemas (`app/schemas/`)

```python
# ✅ CORRECTO
from pydantic import BaseModel, Field
from datetime import datetime
import uuid


class MemberBase(BaseModel):
    login: str = Field(..., min_length=1, max_length=255)
    name: str = Field(..., min_length=1, max_length=255)


class MemberCreate(MemberBase):
    pass


class MemberResponse(MemberBase):
    id: uuid.UUID
    is_active: bool
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)
```

**Schemas base disponibles** (`app/schemas/base.py`):

```python
ApiResponse[T]         # {"success": True, "data": T, "meta": None}
ApiErrorResponse       # {"success": False, "error": ErrorDetail}
PaginatedResponse[T]   # {"success": True, "data": list[T], "meta": PaginationMeta}
PaginationMeta         # {page, per_page, total, total_pages}
```

## Auth0 — Patron de Autenticacion

La autenticacion usa `auth0-fastapi-api` SDK. Siempre usar `get_current_user` de `app/api/v1/dependencies.py`.

```python
# ✅ CORRECTO — proteger endpoint con Auth0
from app.api.v1.dependencies import get_current_user

@router.get("/protected")
async def protected_route(
    current_user: dict = Depends(get_current_user),
) -> ApiResponse[SomeResponse]:
    user_id = current_user["sub"]  # Auth0 user ID
    ...


# Para endpoint publico, simplemente NO agregar el Depends(get_current_user)
@router.get("/public")
async def public_route() -> dict[str, str]:
    return {"status": "ok"}
```

**Excepciones de auth** (se lanzan automaticamente en `get_current_user`):
- `UnauthorizedException` (401) — JWT ausente, invalido o expirado
- `ForbiddenException` (403) — JWT valido pero sin permisos (audience/issuer incorrecto)

## Dependency Injection

```python
# app/api/v1/dependencies.py — agregar dependencias aqui
from typing import Annotated
from fastapi import Depends
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.repositories.member_repository import MemberRepository
from app.services.member_service import MemberService
from app.use_cases.member.create_member import CreateMemberUseCase


async def get_member_repository(
    db: Annotated[AsyncSession, Depends(get_db)]
) -> MemberRepository:
    return MemberRepository(db)


async def get_member_service(
    member_repository: Annotated[MemberRepository, Depends(get_member_repository)]
) -> MemberService:
    return MemberService(member_repository)


async def get_create_member_use_case(
    member_repository: Annotated[MemberRepository, Depends(get_member_repository)],
    member_service: Annotated[MemberService, Depends(get_member_service)],
) -> CreateMemberUseCase:
    return CreateMemberUseCase(member_repository, member_service)
```

## Exception Handling

**Excepciones existentes** (`app/core/exceptions.py`):

```python
AppException          # base, 500, "INTERNAL_ERROR"
UnauthorizedException # 401, "UNAUTHORIZED"
ForbiddenException    # 403, "FORBIDDEN"
```

**Agregar nuevas excepciones siguiendo el patron**:

```python
# app/core/exceptions.py
class NotFoundException(AppException):
    def __init__(self, message: str):
        super().__init__(status_code=404, error_code="NOT_FOUND", message=message)

class ConflictException(AppException):
    def __init__(self, message: str):
        super().__init__(status_code=409, error_code="CONFLICT", message=message)
```

> Los exception handlers ya estan registrados en `main.py` via `register_exception_handlers(app)`.
> Las excepciones AppException se convierten automaticamente al envelope format.

## Listado con Paginacion

```python
# ✅ CORRECTO — use case con paginacion
class ListMembersUseCase:
    def __init__(self, member_repository: MemberRepository) -> None:
        self.member_repository = member_repository

    async def execute(self, page: int, per_page: int) -> tuple[list[Member], int]:
        return await self.member_repository.find_all(page=page, per_page=per_page)


# ✅ CORRECTO — endpoint con PaginatedResponse
@router.get("", response_model=PaginatedResponse[MemberResponse])
async def list_members(
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
    use_case: ListMembersUseCase = Depends(get_list_members_use_case),
    _: dict = Depends(get_current_user),
) -> PaginatedResponse[MemberResponse]:
    members, total = await use_case.execute(page=page, per_page=per_page)
    return PaginatedResponse(
        data=[MemberResponse.model_validate(m) for m in members],
        meta=PaginationMeta(
            page=page,
            per_page=per_page,
            total=total,
            total_pages=(total + per_page - 1) // per_page,
        ),
    )
```

## Performance

### Async en todas partes
```python
# ✅ CORRECTO
async def get_by_id(self, id: UUID) -> Member | None:
    result = await self.session.execute(select(Member).where(Member.id == id))
    return result.scalar_one_or_none()

# ❌ INCORRECTO — bloqueante
def get_by_id(self, id: int) -> Member | None:
    return self.session.query(Member).get(id)
```

### APIs Externas — timeout + retry
```python
# ✅ CORRECTO
import httpx
from tenacity import retry, stop_after_attempt, wait_exponential


class ExternalApiService:
    def __init__(self) -> None:
        self.client = httpx.AsyncClient(
            timeout=httpx.Timeout(10.0, connect=5.0),
            headers={"User-Agent": "newo-api/1.0"},
        )

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=10))
    async def call_endpoint(self, url: str) -> dict:
        response = await self.client.get(url)
        response.raise_for_status()
        return response.json()

    async def close(self) -> None:
        await self.client.aclose()


# ❌ INCORRECTO — sin timeout, sin retry
async def call_endpoint(self, url: str) -> dict:
    async with httpx.AsyncClient() as client:
        response = await client.get(url)
        return response.json()
```

### Background Tasks para operaciones no criticas
```python
from fastapi import BackgroundTasks

@router.post("/webhooks/stripe")
async def handle_webhook(
    payload: WebhookPayload,
    background_tasks: BackgroundTasks,
    _: dict = Depends(get_current_user),
) -> dict[str, str]:
    event_id = await save_event(payload)
    background_tasks.add_task(notify_crm, payload)
    return {"event_id": str(event_id)}
```

## Logging

```python
# ✅ CORRECTO — structured logging
import logging

logger = logging.getLogger(__name__)

async def create_member(self, data: MemberCreate) -> Member:
    logger.info("Creating member login=%s", data.login)
    member = await self.member_repository.create(data)
    logger.info("Member created id=%s", member.id)
    return member

# ❌ INCORRECTO
async def create_member(self, data: MemberCreate) -> Member:
    print(f"Creating member {data.login}")   # NUNCA usar print
    return await self.repo.create(data)
```

## Testing

```python
# tests/unit/test_member_service.py
import pytest
from unittest.mock import AsyncMock
from app.services.member_service import MemberService
from app.core.exceptions import ConflictException


@pytest.mark.asyncio
async def test_validate_unique_login_raises_when_exists():
    # Arrange
    mock_repo = AsyncMock()
    mock_repo.find_by_login.return_value = object()
    service = MemberService(mock_repo)

    # Act & Assert
    with pytest.raises(ConflictException):
        await service.validate_unique_login("existing_login")


@pytest.mark.asyncio
async def test_validate_unique_login_passes_when_not_exists():
    # Arrange
    mock_repo = AsyncMock()
    mock_repo.find_by_login.return_value = None
    service = MemberService(mock_repo)

    # Act & Assert — no exception raised
    await service.validate_unique_login("new_login")
```

## Guia Rapida: Crear un Endpoint Completo

1. **Schema**: `app/schemas/{entity}.py` — Create, Response, Update schemas
2. **Exception** (si necesaria): agregar a `app/core/exceptions.py`
3. **Repository**: `app/repositories/{entity}_repository.py` — extiende `BaseRepository`
4. **Service**: `app/services/{entity}_service.py` — logica de negocio
5. **Use Cases**: `app/use_cases/{entity}/` — un archivo por intencion
6. **Dependencies**: agregar a `app/api/v1/dependencies.py`
7. **Endpoint**: `app/api/v1/endpoints/{entity}.py` — registrar router en `main.py`
8. **Tests**: `tests/unit/test_{entity}_service.py` y `tests/unit/test_{entity}_repository.py`
9. **Migracion** (si nueva tabla): `alembic revision --autogenerate -m "..." --rev-id V0.0.X`

## Anti-patterns a Evitar

- Logica de negocio en endpoints
- Queries directas en endpoints (usar repositories)
- Codigo sincrono bloqueante en funciones async
- Secrets hardcodeados
- `HTTPException` desde services/use_cases
- `print()` en vez de logger
- Llamar APIs externas sin timeout
- Modelos sin `TimestampMixin` ni `SoftDeleteMixin`
- `int` como primary key (usar UUID)
- DELETE fisico (usar soft delete)
- Retornar objetos directamente sin envelope pattern

---

**Version del Skill**: 3.0.0
**Ultima actualizacion**: 2026-02-12
