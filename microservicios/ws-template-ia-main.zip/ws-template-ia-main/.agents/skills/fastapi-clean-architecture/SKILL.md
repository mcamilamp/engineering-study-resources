---
name: fastapi-clean-architecture
description: 'FastAPI Clean Architecture con Use Cases pattern. Guía el desarrollo de endpoints REST siguiendo arquitectura por capas (Endpoint → Use Case → Service → Repository → Model). Se activa al crear, modificar o revisar código Python/FastAPI.'
license: MIT
allowed-tools: Bash
---

# FastAPI Clean Architecture

Skill para desarrollo de endpoints REST en FastAPI usando arquitectura por capas + Use Cases pattern.

## Activación

Se activa cuando el usuario:
- Trabaja con Python/FastAPI
- Crea nuevos endpoints
- Refactoriza código existente
- Solicita "clean architecture" o "use cases"

## Stack

- Python 3.12+
- FastAPI 0.115+
- PostgreSQL + SQLAlchemy 2.0 (async)
- Auth0 via `auth0-fastapi-api`
- Ruff + mypy + pytest

## Capas (en orden)

```
HTTP Request → Endpoint → Use Case → Service → Repository → Model → Schema → HTTP Response
```

Ver `AGENTS.md` para patrones detallados de cada capa.
