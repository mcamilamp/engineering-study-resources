# Java Clean Architecture Skill - logik-business-surveys

## Propósito
Este skill guía el desarrollo de endpoints REST en logik-business-surveys usando Java 17 + Spring Boot 3.2.1 con arquitectura por capas (Layered Architecture) + Use Cases pattern.

> **REGLA FUNDAMENTAL:** Las entidades JPA y repositorios NO se crean en este proyecto. Vienen de la librería `logik-business-persistence:2.0.6`. Las migraciones Flyway SÍ se gestionan aquí.

---

## Stack Tecnológico

### Core
- **Java**: 17
- **Framework**: Spring Boot 3.2.1
- **Build**: Gradle 8.5 (`./gradlew`)
- **ORM**: Spring Data JPA + Hibernate
- **Migraciones**: Flyway 10.18.2 (gestionadas en este proyecto)
- **Mapeo DTO ↔ Entity**: MapStruct 1.5.5
- **Auth**: Spring Security + JWT (`logik-business-security:2.1.2`, validación delegada)

### Librerías Internas (no crear localmente)
| Librería | Versión | Provee |
|----------|---------|--------|
| `logik-business-persistence` | 2.0.6 | Entidades JPA + Repositorios |
| `logik-business-security` | 2.1.2 | SecurityConfig + JwtUtil + RequestInterceptor |
| `logik-business-utils` | 1.2.3 | ApiResponse + Enums + Constantes |

### Quality
- **Tests**: JUnit 5 + Mockito + AssertJ (cobertura ≥ 80%)
- **Linting**: Checkstyle (`./gradlew checkstyleMain`)
- **Análisis estático**: SpotBugs (`./gradlew spotbugsMain`)
- **Cobertura**: JaCoCo (`./gradlew test`)

---

## Flujo de Request (obligatorio)

```
HTTP Request
    ↓
[SecurityConf + RequestInterceptor] — valida JWT (logik-business-security)
    ↓
[Controller v2] — HTTP handling + @Valid
    ↓
[UseCase] — orquestación (una intención = un use case)
    ↓
[Service] — lógica de negocio pura, stateless
    ↓
[Repository] — de logik-business-persistence (JPA + soft delete)
    ↓
[Entity] — de logik-business-persistence (@Entity + auditoría)
    ↓
[ApiResponse<T>] — envelope de logik-business-utils
    ↓
HTTP Response
```

**Ninguna capa puede saltarse a otra.** Un Controller nunca habla directamente con un Repository.

---

## Estructura de Paquetes

```
src/main/java/com/logik/business/surveys/
├── controller/v2/        # @RestController — HTTP only
├── usecase/              # Un caso de uso por intención
├── service/              # @Service — lógica de negocio pura
├── dto/
│   ├── request/          # <Entity>Request con @Valid
│   └── response/         # <Entity>Response
├── mapper/               # @Mapper (MapStruct) — Entity ↔ DTO
├── exception/            # Excepciones custom
├── handler/              # @ControllerAdvice
└── config/               # Beans, configuración local

src/main/resources/
└── db/migration/         # ✅ Migraciones Flyway (V{n}__description.sql)
```

---

## Patrones por Capa

### 1. Controller (`controller/v2/`)

```java
// ✅ CORRECTO
@RestController
@RequestMapping("/business-survey/api/v2/surveys")
@RequiredArgsConstructor
@Tag(name = "Surveys")
public class SurveyController {

    private final SurveyUseCase surveyUseCase;  // UseCase, no Service directamente

    @GetMapping
    public ResponseEntity<ApiResponse<List<SurveyResponse>>> getAll() {
        return ResponseEntity.ok(ApiResponse.success(surveyUseCase.findAll()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<SurveyResponse>> getById(@PathVariable UUID id) {
        return ResponseEntity.ok(ApiResponse.success(surveyUseCase.findById(id)));
    }

    @PostMapping
    public ResponseEntity<ApiResponse<SurveyResponse>> create(
        @Valid @RequestBody SurveyRequest request
    ) {
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(ApiResponse.success(surveyUseCase.create(request)));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<SurveyResponse>> update(
        @PathVariable UUID id,
        @Valid @RequestBody SurveyRequest request
    ) {
        return ResponseEntity.ok(ApiResponse.success(surveyUseCase.update(id, request)));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable UUID id) {
        surveyUseCase.delete(id);
        return ResponseEntity.noContent().build();  // 204
    }
}

// ❌ INCORRECTO — lógica de negocio en controller
@PostMapping
public ResponseEntity<?> create(@RequestBody SurveyRequest request) {
    var entity = new SurveyEntity();  // ❌ nunca crear entities aquí
    repository.save(entity);          // ❌ nunca llamar repository directamente
    return ResponseEntity.ok(entity); // ❌ nunca exponer entity, sin envelope
}
```

**HTTP Status codes:**

| Código | Cuándo |
|--------|--------|
| `200` | GET, PUT, PATCH exitoso |
| `201` | POST — recurso creado |
| `204` | DELETE — soft delete exitoso |
| `400` | Error de validación (`@Valid`) |
| `401` | Token inválido o ausente |
| `403` | Sin permisos |
| `404` | Recurso no encontrado |
| `409` | Conflicto (duplicado) |
| `500` | Error del servidor |

---

### 2. UseCase (`usecase/`)

```java
// ✅ CORRECTO — interfaz del use case
public interface SurveyUseCase {
    List<SurveyResponse> findAll();
    SurveyResponse findById(UUID id);
    SurveyResponse create(SurveyRequest request);
    SurveyResponse update(UUID id, SurveyRequest request);
    void delete(UUID id);
}

// ✅ CORRECTO — implementación que orquesta servicios
@Service
@RequiredArgsConstructor
public class SurveyUseCaseImpl implements SurveyUseCase {

    private final SurveyService surveyService;
    private final SurveyResponseService surveyResponseService;  // cuando necesita múltiples servicios

    @Override
    public SurveyResponse create(SurveyRequest request) {
        surveyService.validateUniqueName(request.name());
        return surveyService.create(request);
    }

    @Override
    public SurveyResponse findById(UUID id) {
        return surveyService.findById(id);
    }
}

// ❌ INCORRECTO — use case con queries directas a DB
@Service
public class SurveyUseCaseImpl implements SurveyUseCase {
    private final SurveyRepository repository;  // ❌ use case no habla con repository

    public SurveyResponse findById(UUID id) {
        return repository.findById(id)...;  // ❌
    }
}
```

---

### 3. Service (`service/`)

```java
// ✅ CORRECTO — interface del servicio
public interface SurveyService {
    List<SurveyResponse> findAll();
    SurveyResponse findById(UUID id);
    SurveyResponse create(SurveyRequest request);
    SurveyResponse update(UUID id, SurveyRequest request);
    void delete(UUID id);
    void validateUniqueName(String name);
}

// ✅ CORRECTO — implementación con inyección por constructor
@Service
@RequiredArgsConstructor
@Slf4j
public class SurveyServiceImpl implements SurveyService {

    private final SurveyRepository surveyRepository;   // de logik-business-persistence
    private final SurveyMapper surveyMapper;            // local

    @Override
    public SurveyResponse create(SurveyRequest request) {
        var entity = surveyMapper.toEntity(request);
        entity.setDeleted(false);
        var saved = surveyRepository.save(entity);
        log.info("Survey created: {}", saved.getId());
        return surveyMapper.toResponse(saved);
    }

    @Override
    public SurveyResponse findById(UUID id) {
        return surveyRepository.findByIdAndDeletedFalse(id)
            .map(surveyMapper::toResponse)
            .orElseThrow(() -> new SurveyNotFoundException(id));
    }

    @Override
    @Transactional
    public void delete(UUID id) {
        var entity = surveyRepository.findByIdAndDeletedFalse(id)
            .orElseThrow(() -> new SurveyNotFoundException(id));
        entity.setDeleted(true);        // soft delete
        surveyRepository.save(entity);
    }

    @Override
    public void validateUniqueName(String name) {
        if (surveyRepository.existsByNameAndDeletedFalse(name)) {
            throw new SurveyGenericException("Ya existe una encuesta con el nombre: " + name);
        }
    }
}

// ❌ INCORRECTO — service con HTTP o ResponseStatusException
public SurveyResponse findById(UUID id) {
    throw new ResponseStatusException(404, "Not found");  // ❌ excepción custom siempre
}
```

---

### 4. DTOs (`dto/`)

```java
// ✅ CORRECTO — Request con validaciones
public record SurveyRequest(
    @NotBlank
    @Size(max = 255)
    String name,

    @Size(max = 1000)
    String description,

    @NotNull
    UUID lineId
) {}

// ✅ CORRECTO — Response (nunca exponer entity)
public record SurveyResponse(
    UUID id,
    String name,
    String description,
    UUID lineId,
    LocalDateTime createdAt,
    LocalDateTime updatedAt
) {}
```

---

### 5. Mapper (`mapper/`)

```java
// ✅ CORRECTO
@Mapper(
    componentModel = "spring",
    nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE
)
public interface SurveyMapper {

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "deleted", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", ignore = true)
    SurveyEntity toEntity(SurveyRequest request);

    SurveyResponse toResponse(SurveyEntity entity);

    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    void updateEntity(SurveyRequest request, @MappingTarget SurveyEntity entity);
}
```

---

### 6. Excepciones (`exception/` + `handler/`)

```java
// ✅ CORRECTO — excepciones custom
public class SurveyNotFoundException extends RuntimeException {
    public SurveyNotFoundException(UUID id) {
        super("Encuesta no encontrada con id: " + id);
    }
}

public class SurveyGenericException extends RuntimeException {
    public SurveyGenericException(String message) {
        super(message);
    }
}

// ✅ CORRECTO — handler global
@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    @ExceptionHandler(SurveyNotFoundException.class)
    public ResponseEntity<ApiResponse<Void>> handleNotFound(SurveyNotFoundException ex) {
        log.warn("Survey not found: {}", ex.getMessage());
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
            .body(ApiResponse.error(ex.getMessage()));
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiResponse<Void>> handleValidation(MethodArgumentNotValidException ex) {
        var errors = ex.getBindingResult().getFieldErrors().stream()
            .map(e -> e.getField() + ": " + e.getDefaultMessage())
            .toList();
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
            .body(ApiResponse.error("Validación fallida", errors));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiResponse<Void>> handleGeneric(Exception ex) {
        log.error("Error inesperado", ex);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
            .body(ApiResponse.error("Error interno del servidor"));
    }
}
```

---

### 7. Migraciones Flyway (`src/main/resources/db/migration/`)

Las migraciones **SÍ** se gestionan en este proyecto. Convención obligatoria:

```
V{version}__description.sql
```

```sql
-- ✅ CORRECTO — V18__add_survey_category.sql
ALTER TABLE surveys
ADD COLUMN category NVARCHAR(100) NULL;

-- ✅ CORRECTO — nueva tabla relacionada
-- V19__add_survey_tags.sql
CREATE TABLE survey_tags (
    id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID() PRIMARY KEY,
    survey_id UNIQUEIDENTIFIER NOT NULL,
    tag NVARCHAR(100) NOT NULL,
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    updated_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    deleted BIT NOT NULL DEFAULT 0,
    CONSTRAINT fk_survey_tags_survey FOREIGN KEY (survey_id)
        REFERENCES surveys(id)
);
```

**Tabla de control:** `flyway_schema_history_survey`

**Reglas:**
- NUNCA modificar una migración ya aplicada
- SIEMPRE incrementar el número de versión
- Coordinar con el equipo de `logik-business-persistence` cuando afecte entidades compartidas
- La DB actual es **SQL Server** (en migración a PostgreSQL)

---

## ApiResponse — Envelope Pattern

```java
// ✅ SIEMPRE usar ApiResponse de logik-business-utils
return ResponseEntity.ok(ApiResponse.success(response));              // 200 con data
return ResponseEntity.status(201).body(ApiResponse.success(created)); // 201 con data
return ResponseEntity.noContent().build();                            // 204 sin body

// ❌ NUNCA devolver entity o DTO directamente
return ResponseEntity.ok(entity);    // ❌
return ResponseEntity.ok(response);  // ❌
```

**Formatos de respuesta:**
```json
{ "success": true,  "data": { ... },  "meta": null }
{ "success": true,  "data": [ ... ],  "meta": { "page": 0, "size": 20, "total": 100 } }
{ "success": false, "error": { "code": "NOT_FOUND", "message": "...", "details": [] } }
```

---

## Tests

```java
// ✅ CORRECTO — patrón AAA con Mockito + AssertJ
// src/test/java/.../service/SurveyServiceTest.java
@ExtendWith(MockitoExtension.class)
class SurveyServiceTest {

    @Mock
    private SurveyRepository surveyRepository;

    @Mock
    private SurveyMapper surveyMapper;

    @InjectMocks
    private SurveyServiceImpl surveyService;

    @Test
    void findById_whenExists_returnsResponse() {
        // Arrange
        var id = UUID.randomUUID();
        var entity = new SurveyEntity();
        var response = new SurveyResponse(id, "Test", null, null, null, null);
        given(surveyRepository.findByIdAndDeletedFalse(id)).willReturn(Optional.of(entity));
        given(surveyMapper.toResponse(entity)).willReturn(response);

        // Act
        var result = surveyService.findById(id);

        // Assert
        assertThat(result).isNotNull();
        assertThat(result.id()).isEqualTo(id);
        then(surveyRepository).should().findByIdAndDeletedFalse(id);
    }

    @Test
    void findById_whenNotExists_throwsNotFoundException() {
        // Arrange
        var id = UUID.randomUUID();
        given(surveyRepository.findByIdAndDeletedFalse(id)).willReturn(Optional.empty());

        // Act & Assert
        assertThatThrownBy(() -> surveyService.findById(id))
            .isInstanceOf(SurveyNotFoundException.class);
    }
}
```

**Comandos:**
```bash
./gradlew test              # Ejecutar todos los tests + cobertura
./gradlew checkstyleMain    # Estilo de código
./gradlew spotbugsMain      # Análisis estático
./gradlew check             # Pipeline completo
```

---

## Guía Rápida: Crear un Endpoint Completo

1. **DTO**: `dto/request/<Entity>Request.java` + `dto/response/<Entity>Response.java`
2. **Excepción** (si necesaria): `exception/<Entity>NotFoundException.java`
3. **Mapper**: `mapper/<Entity>Mapper.java` — MapStruct
4. **Service interface**: `service/<entity>/<Entity>Service.java`
5. **Service impl**: `service/<entity>/<Entity>ServiceImpl.java` — inyecta repo de persistence
6. **UseCase interface**: `usecase/<entity>/<Entity>UseCase.java`
7. **UseCase impl**: `usecase/<entity>/<Entity>UseCaseImpl.java` — orquesta services
8. **Controller**: `controller/v2/<Entity>Controller.java` — inyecta use case
9. **Tests**: `service/<Entity>ServiceTest.java` + `controller/<Entity>ControllerTest.java`
10. **Migración** (si columna/tabla nueva): `db/migration/V{n+1}__add_<description>.sql`

---

## Anti-patterns a Evitar

- Crear `@Entity` en este proyecto (vienen de `logik-business-persistence`)
- Crear `@Repository` en este proyecto (vienen de `logik-business-persistence`)
- Crear `SecurityConfig` o `JwtUtil` localmente (delegado a `logik-business-security`)
- Lógica de negocio en controllers
- Controller llamando directamente al repository (saltarse capas)
- `ResponseStatusException` desde services o use cases — usar excepciones custom
- Exponer entities directamente en respuestas HTTP
- Respuestas sin `ApiResponse` envelope
- Inyección de dependencias con `@Autowired` en campo — usar constructor
- `@Autowired` en campos (usar constructor siempre)
- DELETE físico en base de datos — usar soft delete (`deleted = true`)
- Modificar migraciones Flyway ya aplicadas

---

**Versión del Skill**: 1.0.0
**Última actualización**: 2026-02-19
**Stack**: Java 17 · Spring Boot 3.2.1 · Gradle 8.5
