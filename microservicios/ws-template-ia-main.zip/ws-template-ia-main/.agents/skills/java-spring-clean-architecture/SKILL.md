---
name: java-spring-clean-architecture
description: 'Java Spring Boot Clean Architecture con Use Cases pattern. Guía el desarrollo de endpoints REST siguiendo arquitectura por capas (Controller → UseCase → Service → Repository). Se activa al trabajar con código Java/Spring Boot.'
license: MIT
allowed-tools: Bash
---

# Java Spring Boot Clean Architecture

Skill para desarrollo de endpoints REST en Java 17 + Spring Boot 3.2.1 con arquitectura por capas.

## Librerías Externas (NO crear localmente)

| Librería | Versión | Provee |
|----------|---------|--------|
| `logik-business-persistence` | 2.0.6 | Entidades JPA + Repositorios |
| `logik-business-security` | 2.1.2 | SecurityConfig + JwtUtil |
| `logik-business-utils` | 1.2.3 | ApiResponse + Enums |

## Capas (en orden)

```
HTTP Request → Controller → UseCase → Service → Repository → Entity → ApiResponse
```

Ver `AGENTS.md` para patrones detallados de cada capa.
