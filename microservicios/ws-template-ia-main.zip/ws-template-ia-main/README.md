# Configuración Global de Claude

## Instrucciones para CLAUDE.md global

Para que Claude automáticamente detecte y siga las instrucciones de SDD en todos tus proyectos, agrega lo siguiente a tu archivo `CLAUDE.md` global (ubicado en `C:\Users\LENOVO\.claude\CLAUDE.md`):

```markdown
# Global Claude Instructions

When working in any project:

1. Look for an `AGENTS.md` file in the project root

2. If found, read it completely and follow its instructions as your operating context

3. If it contains SDD orchestrator instructions, activate that workflow
```

## Proyectos con SDD

Este proyecto contiene:
- `AGENTS.md` - Instrucciones del orquestador SDD
- `.agents/skills/` - Habilidades SDD disponibles

Con la configuración global anterior, Claude automáticamente:
- Detectará el archivo `AGENTS.md` en cualquier proyecto
- Activará el flujo de trabajo SDD cuando esté disponible
- Podrá ejecutar comandos como `/sdd:init`, `/sdd:new`, `/sdd:apply`, etc.
